// Fill out your copyright notice in the Description page of Project Settings.


#include "Observador.h"

// Add default functionality here for any IObservador functions that are not pure virtual.
